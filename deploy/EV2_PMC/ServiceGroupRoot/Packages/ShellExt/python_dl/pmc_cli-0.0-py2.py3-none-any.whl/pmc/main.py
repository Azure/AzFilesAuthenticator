def run():
    print("Error: pmc-cli was installed from PyPI. "
          "Please open an issue at https://github.com/microsoft/linux-package-repositories if you "
          "need assistance.")
